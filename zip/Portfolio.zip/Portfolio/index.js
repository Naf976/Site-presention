let toogle = document.querySelector(".toogle");
let body = document.querySelector("body");
toogle.addEventListener("click", ()=>{
    body.classList.toggle("open");

})



